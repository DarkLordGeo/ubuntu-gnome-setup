// SPDX-License-Identifier: AGPL-3.0-or-later
//
// Nonlinear animation is all you need: make GNOME's overview/workspace/window
// animations feel more macOS-like (smooth easing curves, springs, velocity
// continuity) by wrapping the prototype ease methods gnome-shell adds in
// js/ui/environment.js.
//
// Curve model (curves.js): native-mode presets, N-point monotone splines and
// damped springs. Native modes are applied by just swapping params.mode
// (zero overhead). Custom curves are driven per-frame: the transition is left
// fully native (completion signals, remove-on-complete, the shell's own
// callbacks all keep working) and a connect_after('new-frame') handler writes
// the eased value right after the class handler each frame (continuity.js).
//
// Interruption continuity: when a new ease replaces a still-playing one,
// gnome-shell restarts from the current position with zero velocity: the
// "second app-grid page re-accelerates from standstill" jolt. We read the old
// animation's velocity from our registry and seed the new curve with it.
//
// All settings are live (GSettings reads are cached lookups, not IPC).

import Clutter from 'gi://Clutter';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import Graphene from 'gi://Graphene';
import St from 'gi://St';
import System from 'system';
import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';

import * as Curves from './curves.js';
import {
    MAX_V0,
    MIN_V0,
    bridgeLive,
    bridgeShutdown,
    bridgeStartup,
    driveTransition,
    motionState,
    noteModeAnimation,
    seedAdjustmentTransition,
    dropSamplersOf,
} from './continuity.js';
import {makeBezierEvaluator} from './easing.js';

// WorkspaceAnimation drives one MonitorGroup per monitor through a custom
// 'progress' property (gdouble) eased via ease_property. Easing it used to
// flicker secondary monitors on multi-head fractional-scale setups (issue
// #1), so it is gated behind the workspace-switch setting; users on that
// hardware can turn it off while everyone else keeps the eased switch.
import * as WorkspaceAnimation from
    'resource:///org/gnome/shell/ui/workspaceAnimation.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
const MonitorGroup = WorkspaceAnimation.MonitorGroup ?? null;

// Stay out of the way while the shell is still coming up at login: the boot
// sequence (first layout passes, chrome fades) is timing-sensitive on
// multi-monitor setups and "sometimes fails to initialize" (issue #1).
const BOOT_GRACE_MS = 8000;

const MODE_MAP = {
    'ease-out-cubic': Clutter.AnimationMode.EASE_OUT_CUBIC,
    'ease-out-expo': Clutter.AnimationMode.EASE_OUT_EXPO,
    'ease-out-quart': Clutter.AnimationMode.EASE_OUT_QUART,
    'ease-out-quint': Clutter.AnimationMode.EASE_OUT_QUINT,
    'ease-in-out-cubic': Clutter.AnimationMode.EASE_IN_OUT_CUBIC,
    'ease-in-out-quart': Clutter.AnimationMode.EASE_IN_OUT_QUART,
    'ease-in-out-quint': Clutter.AnimationMode.EASE_IN_OUT_QUINT,
    'ease-in-out-expo': Clutter.AnimationMode.EASE_IN_OUT_EXPO,
    'ease-out-back': Clutter.AnimationMode.EASE_OUT_BACK,
};

// Keys of the ease params object that control the animation rather than name
// an animated property (mirrors what gnome-shell's own helpers consume).
const CONTROL_KEYS = new Set([
    'duration', 'delay', 'mode', 'progress_mode', 'repeatCount', 'autoReverse',
    'animationRequired', 'onComplete', 'onStopped',
]);

// GObject type names we can drive numerically. Anything else (booleans,
// enums, boxed values, '@'-escaped sub-object properties) is left native.
const NUMERIC_TYPES = new Set(['gfloat', 'gdouble', 'gint', 'guint']);

// Diagnostic logging for the journal, greppable as "nla-debug". Deduped
// per tag for the whole session: the logger itself can never become the
// storm it is hunting.
const dbgSeen = new Set();
const dbg = tag => {
    if (!dbgSeen.has(tag)) {
        dbgSeen.add(tag);
        console.log(`nla-debug: ${tag}`);
    }
};
const GVALUE_SETTERS = {
    gfloat: 'set_float',
    gdouble: 'set_double',
    gint: 'set_int',
    guint: 'set_uint',
};

// compiz-alike-magic-lamp-effect drives its minimize/unminimize DeformEffect
// with a Clutter.Timeline left at default LINEAR progress, so the window
// collapses into the dock at full speed and stops dead. When the user opts
// in (magic-lamp-easing setting), we set that timeline's progress_mode to
// EASE_OUT_CUBIC so it decelerates into the dock. The effect names must match
// the constants in compiz-alike-magic-lamp-effect/extension.js.
const MAGIC_LAMP_MINIMIZE = 'minimize-magic-lamp-effect';
const MAGIC_LAMP_UNMINIMIZE = 'unminimize-magic-lamp-effect';

export default class SpringEaseExtension extends Extension {
    enable() {
        bridgeStartup();
        this._settings = this.getSettings();
        this._migrateSettings();

        this._orig = {
            ease: Clutter.Actor.prototype.ease,
            easeProperty: Clutter.Actor.prototype.ease_property,
            easeAsync: Clutter.Actor.prototype.easeAsync,
            adjustmentEase: St.Adjustment.prototype.ease,
        };

        const settings = this._settings;
        const orig = this._orig;

        // Curve cache: resolved per ease call without re-parsing JSON.
        // Invalidated live when the selection, the curve library or the
        // spring solver changes.
        let curve = this._resolveCurve(settings);
        const invalidateCurve = () => (curve = this._resolveCurve(settings));
        settings.connectObject(
            'changed::selected-curve', invalidateCurve,
            'changed::user-curves', invalidateCurve,
            'changed::spring-solver', invalidateCurve,
            this);

        // Dispose guard: an actor can be destroyed inside its own ease()
        // (very short animations complete synchronously and their onComplete
        // destroys the actor). Touching it afterwards logs a GJS CRITICAL
        // that try/catch cannot intercept (property access on a disposed
        // GObject warns instead of throwing), so mark targets at destroy
        // time and skip them in postEase. One connection per actor for its
        // whole lifetime, never per ease call.
        const disposedTargets = new WeakSet();
        const disposeHooked = new WeakSet();
        const hookDispose = target => {
            if (disposeHooked.has(target))
                return;
            disposeHooked.add(target);
            // Only Clutter.Actor has a destroy signal; St.Adjustment
            // (the other animated target type) is a plain GObject, and
            // adjustments are never disposed mid-note in practice.
            if (!(target instanceof Clutter.Actor))
                return;
            target.connect('destroy', () => {
                disposedTargets.add(target);
                dropSamplersOf(target);
            });
        };

        // Touchpad-gesture exclusion: when the user drives an overview/workspace
        // open with a 3-finger swipe, the motion is gesture-driven (it already
        // tracks the finger). We leave the wrap-up animation at GNOME's native
        // speed so it doesn't feel dragged after release. Discrete triggers
        // (Super key) still get the curve. We stamp the last gesture event time
        // and skip springify for a short grace window after it.
        let lastGestureTime = 0;
        global.stage.connectObject('captured-event', (_stage, event) => {
            const t = event.type();
            if (t === Clutter.EventType.TOUCHPAD_SWIPE ||
                t === Clutter.EventType.TOUCHPAD_PINCH) {
                // 3-/4-finger swipe, pinch
                lastGestureTime = Date.now();
            } else if (t === Clutter.EventType.SCROLL) {
                // 2-finger touchpad scroll (app-grid / overview paging) arrives as
                // a SCROLL event whose source is FINGER/CONTINUOUS, NOT a mouse
                // wheel. Without this, 2-finger pages aren't seen as gestures and
                // get the full in-out+scaled treatment (the "stutter").
                const src = event.get_scroll_source?.();
                if (src === Clutter.ScrollSource.FINGER ||
                    src === Clutter.ScrollSource.CONTINUOUS)
                    lastGestureTime = Date.now();
            }
            return Clutter.EVENT_PROPAGATE;
        }, this);

        const bootTime = Date.now();

        // --- shared plan for one ease call ---------------------------------
        // Runs BEFORE the original ease: mutates params (mode/duration) and
        // collects what postEase() must do afterwards (per-prop drivers with
        // optional velocity seed). Returns null when nothing should happen.
        // forcedProp/forcedValue are set for the ease_property / Adjustment
        // forms, where the animated property name and its target value live
        // outside the params object.
        const planEase = (target, props, forcedProp, forcedValue) => {
            try {
                return planEaseInner(target, props, forcedProp, forcedValue);
            } catch (e) {
                // Never let a settings/read hiccup break the caller's ease,
                // but never swallow it silently again either; a dead
                // engine shipped for four days behind a quiet catch.
                console.warn(`nonlinear-animation: ${e.message}`);
                return null;
            }
        };
        const planEaseInner = (target, props, forcedProp, forcedValue) => {
            if (!props || typeof props !== 'object' || props.duration === undefined)
                return null;
            if (props.duration < settings.get_int('threshold-ms'))
                return null;
            if (Date.now() - bootTime < BOOT_GRACE_MS)
                return null;
            // Accessibility: when the user asks the system to reduce motion
            // or disable animations, play exactly as GNOME would. GNOME 51
            // wires the reduced-motion preference into its own window
            // animations; easing them anyway would stretch the very motion
            // the setting removes. enable-animations exists on 49-51;
            // St.ReducedMotion is 51-only, so it is feature-tested.
            const stSettings = St.Settings.get();
            if (!stSettings.enableAnimations ||
                (St.ReducedMotion !== undefined &&
                 stSettings.reducedMotion === St.ReducedMotion.REDUCE))
                return null;

            const grace = settings.get_int('gesture-grace-ms');
            const inGrace = grace > 0 && Date.now() - lastGestureTime < grace;
            if (inGrace) {
                // Gesture-driven motion already carries the finger's momentum.
                // For the wrap-up we ONLY decelerate (ease-out): an in-out curve
                // would decelerate-then-accelerate and jolt against the gesture's
                // velocity. We keep GNOME's velocity-matched EASE_OUT_CUBIC (its
                // t=0 derivative matches the release velocity) but stretch the
                // duration a touch so the deceleration phase reads more.
                // gscale defaults 1.3; 1.0 = gestures fully native (the schema
                // documents that value as untouched, so nothing is forced).
                const gscale = settings.get_double('gesture-duration-scale');
                if (gscale !== 1.0) {
                    props.mode = Clutter.AnimationMode.EASE_OUT_CUBIC;
                    props.duration = Math.min(5000,
                        Math.round(props.duration * gscale));
                }
                return null;  // native path, no driver, no continuity
            }

            const c = curve;
            if (!c)
                return null;

            const applyCurve = settings.get_boolean('custom-curves');
            const momentum = settings.get_double('momentum');
            // Direction-aware inertia scaling: same-direction carry (app
            // list paging) and reversal buffering (minimize/restore bounce)
            // are different phenomena and are tuned independently.
            const reversal = settings.get_boolean('reversal-enabled')
                ? settings.get_double('reversal') : 0;

            // The overview state adjustment is the choreography spine; the
            // shell sequences transitions around its native duration, and a
            // hide during show is deferred until it finishes. Capping its
            // scale keeps that machinery within design tolerances.
            let dscale = settings.get_double('duration-scale');
            if (target === Main.overview?._overview?.controls?._stateAdjustment)
                dscale = Math.min(dscale, 1.5);
            props.duration = Math.min(5000, Math.round(props.duration * dscale));

            // Collect animated (property, new target value) pairs.
            // '@'-escaped sub-object properties are left native (the value is
            // not a plain number on this actor).
            const animated = [];
            if (forcedProp !== null) {
                animated.push([forcedProp, forcedValue]);
            } else {
                for (const key of Object.keys(props)) {
                    if (CONTROL_KEYS.has(key))
                        continue;
                    animated.push([key.replaceAll('_', '-'), props[key]]);
                }
            }

            // Drivers (JS per-frame writes) are for ACTOR targets only:
            // writing an St.Adjustment from a driver goes through
            // notify::value, and the controls layer's reaction makes mutter
            // kill the transition being driven (the drawer froze mid-open
            // and snapped). Adjustments get continuity through purely native
            // mechanics instead: interval-rewrite + velocity-matched bezier
            // progress, evaluated in C.
            const isActor = target instanceof Clutter.Actor;
            const continuityOn = settings.get_boolean('continuity');
            const simpleCase = props.delay === undefined &&
                props.repeatCount === undefined;

            // Pass 1: per property, reconstruct the previous motion state and
            // whether the caller reset the property for a replay.
            const candidates = [];
            const numericProps = [];
            // Bounded pspecs: an overshooting curve (elastic, back, spring
            // nod) pushing a FINITE-range property out of range makes GLib
            // log an invalid-value warning on every single frame; at 60Hz
            // the journal write storm starves the main loop and the shell
            // stops responding (host freeze 2026-10-28: slide-x, [-0.02,
            // 1.37] against a [0,1] pspec, warning flood until the shell
            // died). Custom actor properties can be bounded (slide-x,
            // progress), so this is not an adjustment-only concern; stock
            // x/y/translation pspecs span G_MAXFLOAT and stay exempt.
            let boundedProp = null;
            const pspecBounds = pspec => {
                try {
                    const mn = pspec.minimum, mx = pspec.maximum;
                    if (typeof mn === 'number' && typeof mx === 'number' &&
                            Number.isFinite(mn) && Number.isFinite(mx) &&
                            mx > mn && mx - mn < 1e9)
                        return [mn, mx];
                } catch {
                    // introspection of range fields is best-effort
                }
                return null;
            };
            for (const [prop, newTarget] of animated) {
                const pspec = target.find_property?.(prop);
                const typeName = pspec?.value_type?.name;
                if (!typeName || !NUMERIC_TYPES.has(typeName))
                    continue;
                if (typeof newTarget !== 'number' || !Number.isFinite(newTarget))
                    continue;
                const isInt = typeName === 'gint' || typeName === 'guint';
                const bounds = pspecBounds(pspec);
                if (bounds && !boundedProp)
                    boundedProp = prop;

                let cand = null;
                if (continuityOn && simpleCase) {
                    const state = motionState(target, prop);
                    if (state) {
                        const remaining = newTarget - state.value;
                        if (Math.abs(remaining) > 1e-6) {
                            // Anti-teleport: bridge over a reset only when the
                            // caller snapped the property onto the previous
                            // animation's endpoints (replay semantics, e.g.
                            // minimize/unminimize resetting to the icon
                            // geometry). A genuine geometry change (workspace
                            // move, resize) lands anywhere else and must start
                            // from its own new value, or windows end up
                            // animating from stale positions.
                            let fromValue;
                            const nowValue = target[prop.replaceAll('-', '_')];
                            const rangeAbs = Math.abs(state.final - state.init);
                            // A reset is "the property jumped away from the
                            // visual position". The old absolute 0.5 threshold
                            // left the whole upper half of a scale travel
                            // (range ~0.85) unprotected: interrupts past the
                            // halfway point bridged nothing and the driver
                            // started from the reset value, so the window
                            // instantly grew to full size. Any jump larger
                            // than ~1% of the old travel is a reset.
                            if (typeof nowValue === 'number' &&
                                Number.isFinite(nowValue) &&
                                rangeAbs > 1e-6 &&
                                Math.abs(nowValue - state.value) >
                                    Math.max(0.01 * rangeAbs,
                                        0.01 * Math.abs(remaining)) &&
                                (Math.abs(nowValue - state.init) < 0.1 * rangeAbs ||
                                 Math.abs(nowValue - state.final) < 0.1 * rangeAbs))
                                fromValue = state.value;
                            const start = fromValue ?? state.value;
                            // Which inertia applies is a property of THIS
                            // interruption, not of the velocity's sign: a
                            // reversal is when the old velocity opposes the
                            // NEW travel direction. Selecting the knob by
                            // sign(state.velocity) alone made a
                            // restore-then-minimize interrupt (positive
                            // velocity, downward travel) take the momentum
                            // channel, so switching reversal buffering off
                            // still bounced in that direction.
                            const opposing = (newTarget - start) !== 0 &&
                                state.velocity *
                                    (newTarget - start) < 0;
                            const carried = state.velocity *
                                (opposing ? reversal : momentum);
                            cand = {
                                prop, isInt, typeName,
                                gtype: pspec.value_type,
                                fromValue,
                                stateValue: state.value,
                                stateVelocity: carried,
                                bounds,
                                naturalV0: carried * props.duration /
                                    (newTarget - start),
                                span: Math.abs(newTarget - start),
                            };
                        }
                    }
                }
                if (cand) {
                    candidates.push(cand);
                } else if (applyCurve && isActor && simpleCase &&
                        prop !== 'opacity' &&
                        (c.kind === 'spline' || c.kind === 'spring')) {
                    // A custom spline/spring has no native Clutter mode, so
                    // it can only play through the JS driver; without a
                    // candidate here the user's curve only showed on
                    // interruptions (fresh animations fell back to GNOME's
                    // own curve), which reads as "does nothing".
                    // Minimal candidate: no bridge state, zero velocity;
                    // driveTransition takes init/final from the transition.
                    candidates.push({
                        prop, isInt, typeName,
                        gtype: pspec.value_type,
                        naturalV0: 0, span: 0, bounds,
                    });
                } else {
                    numericProps.push(prop);
                }
            }

            // Pass 2: properties of one ease must move along ONE shared
            // retarget curve. Giving each property its own seeded spring let
            // scale-x and scale-y drift apart mid-flight and windows visibly
            // stretch. The dominant property (largest travel) defines the
            // shared velocity seed; every property maps that one progress
            // curve onto its own [start, target] range, so relative geometry
            // (aspect ratio included) stays locked for the whole animation.
            // Bridging is all-or-nothing: if any property restarts from its
            // pre-reset position, every property with a motion state must,
            // or x and y set off from different eras and the window skews.
            const anyBridge = candidates.some(c => c.fromValue !== undefined);
            if (anyBridge) {
                for (const cand of candidates)
                    if (cand.fromValue === undefined)
                        cand.fromValue = cand.stateValue;
            }
            let sharedV0 = null;
            let bestSpan = 0;
            for (const cand of candidates) {
                if (Math.abs(cand.naturalV0) < MIN_V0 && cand.fromValue === undefined)
                    continue;
                if (cand.span > bestSpan) {
                    bestSpan = cand.span;
                    sharedV0 = cand.naturalV0;
                }
            }
            if (sharedV0 !== null)
                sharedV0 = Math.max(-MAX_V0, Math.min(MAX_V0, sharedV0));

            // Interruptions resolve FASTER, not slower: a retarget that keeps
            // the full (stretched) duration crawls into its target for
            // hundreds of milliseconds after the eye has decided the motion
            // is over. Shrink the retarget to 60% so the redirect is quick
            // and the settle decisive. v0 scales linearly with duration, so
            // scaling the seed here matches the shorter window exactly.
            if (sharedV0 !== null || anyBridge) {
                props.duration = Math.max(150, Math.round(props.duration * 0.6));
                sharedV0 = sharedV0 === null ? null : sharedV0 * 0.6;
            }

            const drivers = [];
            const adjSeeds = [];
            for (const cand of candidates) {
                if (cand.prop === 'opacity')
                    continue;  // opacity is fully native (see below)
                const seed = sharedV0 === null && cand.fromValue === undefined
                    ? null
                    : {fromValue: cand.fromValue, v0: sharedV0 ?? 0};
                if (isActor && simpleCase &&
                    (seed !== null ||
                        (applyCurve &&
                            (c.kind === 'spline' || c.kind === 'spring')))) {
                    drivers.push({...cand, seed});
                } else if (!isActor && seed !== null) {
                    // Adjustments are never driven from JS (their value
                    // writes go through notify::value and mutter kills the
                    // transition); continuity is seeded through native
                    // mechanics instead: interval rewrite + velocity-matched
                    // bezier progress, evaluated in C.
                    adjSeeds.push({...cand, seed});
                } else {
                    numericProps.push(cand.prop);
                }
            }

            if (applyCurve && c.kind === 'mode') {
                let mode = MODE_MAP[c.mode];
                if (mode !== undefined) {
                    // Overshooting modes must never run against a bounded
                    // pspec (see the slide-x note above): the per-frame
                    // range warning floods the journal and starves the
                    // main loop. Adjustments are ALWAYS bounded semantics
                    // ([0,1] control surfaces); actors only when their
                    // pspec actually declares a finite range.
                    if ((boundedProp || !isActor) &&
                            (mode === Clutter.AnimationMode.EASE_OUT_BACK ||
                             mode === Clutter.AnimationMode.EASE_OUT_ELASTIC)) {
                        mode = Clutter.AnimationMode.EASE_IN_OUT_CUBIC;
                        dbg(`clamp-mode ${c.mode} -> in-out-cubic ` +
                            `prop=${boundedProp ?? '(adj)'} ` +
                            `actor=${isActor}`);
                    }
                    props.mode = mode;
                }
            }
            // For custom curves the native mode under the driver is invisible
            // (we overwrite the value every frame); whatever mode the caller
            // asked for keeps running underneath until our handler runs.
            hookDispose(target);

            // Opacity stays native on purpose: GNOME fades windows out during
            // minimize and hard-resets opacity at map; carrying the fade
            // state across an interruption chain drained windows into ghosts
            // (opacity 12 -> 1 while still on screen) and the map reset
            // popped 47 -> 255. Native fades are short and reset cleanly.

            return {curve: c, drivers, adjSeeds, numericProps,
                animatedProps: animated.map(([p]) => p),
                carryMomentum: continuityOn,
                momentum, reversal};
        };

        // --- after the original ease --------------------------------------
        const postEase = (target, plan) => {
            if (!plan || disposedTargets.has(target))
                return;
            try {
                // Opacity is a function of POSITION, not time: the window
                // fades in proportion to how far it has traveled along its
                // minimize/restore path, so whatever the velocity profile
                // does (interruptions, reversals, spring overshoot); the
                // fade stays glued to the motion instead of fighting it on
                // an independent timeline. Ride the opacity transition's
                // own frames (guaranteed the last write after its class
                // handler) and derive the value from the current scale.
                if (target.meta_window !== undefined &&
                    plan.animatedProps?.includes('opacity') &&
                    plan.animatedProps?.includes('scale-x')) {
                    const sIv = target.get_transition?.('scale-x')
                        ?.get_interval?.();
                    const oTr = target.get_transition?.('opacity');
                    const lo = Math.min(sIv?.peek_initial_value?.() ?? 0,
                        sIv?.peek_final_value?.() ?? 1);
                    const hi = Math.max(sIv?.peek_initial_value?.() ?? 0,
                        sIv?.peek_final_value?.() ?? 1);
                    if (oTr?.is_playing?.() && hi - lo > 1e-6) {
                        const gv = new GObject.Value();
                        gv.init(GObject.TYPE_UINT);
                        const writeOp = v => {
                            gv.set_uint(Math.max(0, Math.min(255,
                                Math.round(v))));
                            target.set_final_state('opacity', gv);
                        };
                        let oh = 0;
                        // Zero the id on every disconnect: Clutter stops
                        // an actor's transitions after it leaves the tree,
                        // so the 'stopped' handler and a guard branch can
                        // both try to drop the same handler id (a stale
                        // id logs a GObject CRITICAL).
                        const dropOh = () => {
                            if (oh) {
                                oTr.disconnect(oh);
                                oh = 0;
                            }
                        };
                        const derive = () => {
                            try {
                                if (!bridgeLive()) {
                                    dropOh();
                                    return;
                                }
                                // The window actor can be destroyed while
                                // its opacity transition still ticks (panel
                                // workspace dots during rapid switches);
                                // reading it then floods CRITICALs, so bail.
                                if (disposedTargets.has(target)) {
                                    dropOh();
                                    return;
                                }
                                const s = target.scale_x;
                                if (typeof s !== 'number' ||
                                        !Number.isFinite(s))
                                    return;
                                const p = Math.max(0, Math.min(1,
                                    (s - lo) / (hi - lo)));
                                writeOp(255 * p);
                            } catch {
                                // target destroyed mid-derive: stop riding
                                dropOh();
                            }
                        };
                        derive();
                        oh = oTr.connect_after('new-frame', derive);
                        oTr.connect('stopped', () => {
                            dropOh();
                            derive();
                        });
                    }
                }
                for (const d of plan.drivers) {
                    // Write through the ClutterAnimatable interface, the same
                    // channel the transition itself uses. A plain property set
                    // emits notify, which invalidates stage views and makes
                    // mutter kill the very transition we are driving; the
                    // animatable path for x/y etc. bypasses notify entirely.
                    // The GValue is allocated once per animation and reused
                    // every frame (typed to the property's exact GType).
                    const gv = new GObject.Value();
                    gv.init(d.gtype);
                    const set = GVALUE_SETTERS[d.typeName];
                    // Integer properties must stay inside their GType range:
                    // a retarget curve can undershoot (reversal nod) and
                    // writing opacity as a negative number throws
                    // "value is out of range for uint32" inside the frame
                    // handler.
                    const round = d.isInt
                        ? (d.typeName === 'guint'
                            ? (v => Math.max(0, Math.min(4294967295,
                                Math.round(v))))
                            : (v => Math.max(-2147483648,
                                Math.min(2147483647, Math.round(v)))))
                        : (v => v);
                    // A bounded pspec also bounds the driver: overshooting
                    // spline/spring curves would otherwise write out-of-range
                    // values and trigger the same per-frame warning storm
                    // the mode clamp above guards against.
                    const clampB = d.bounds
                        ? (v => Math.max(d.bounds[0], Math.min(d.bounds[1], v)))
                        : (v => v);
                    if (d.bounds)
                        dbg(`clamp-driver prop=${d.prop} ` +
                            `[${d.bounds[0]}, ${d.bounds[1]}]`);
                    const write = v => {
                        gv[set](round(clampB(v)));
                        target.set_final_state(d.prop, gv);
                    };
                    driveTransition(target, d.prop, plan.curve, write, d.seed);
                }
                for (const s of plan.adjSeeds) {
                    // Native continuity for adjustments: no JS per frame.
                    const gv = new GObject.Value();
                    gv.init(s.gtype);
                    const set = GVALUE_SETTERS[s.typeName];
                    const round = s.isInt
                        ? (v => Math.max(0, Math.min(4294967295, Math.round(v))))
                        : (v => v);
                    gv[set](round(s.seed.fromValue ?? 0));
                    seedAdjustmentTransition(target, s.prop, s.seed,
                        m0 => makeBezierEvaluator(0.32,
                            Math.max(-0.45, Math.min(0.5, m0 * 0.32)),
                            0.62, 1.0),
                        gv, v => gv[set](round(v)),
                        (x, y) => Graphene.Point.alloc().init(x, y));
                }
                // Register plain-mode (and non-driven numeric) animations so a
                // later interruption can read their velocity.
                for (const prop of plan.numericProps) {
                    if (!plan.drivers.some(d => d.prop === prop) &&
                        !plan.adjSeeds.some(s => s.prop === prop))
                        noteModeAnimation(target, prop, plan.curve,
                            () => {
                                try {
                                    return target.get_transition?.(prop);
                                } catch {
                                    // actor destroyed between the ease and
                                    // the registry note; nothing to register
                                    return null;
                                }
                            });
                }
            } catch (e) {
                console.warn(`nonlinear-animation: ${e.message}`);
            }
        };

        // MonitorGroup (workspace switching) is eased only when the
        // workspace-switch setting allows it; see the import note above.
        const skipActor = actor =>
            MonitorGroup && actor instanceof MonitorGroup &&
            !settings.get_boolean('workspace-switch');

        Clutter.Actor.prototype.ease = function (props) {
            if (skipActor(this))
                return orig.ease.call(this, props);
            const plan = planEase(this, props, null, null);
            const r = orig.ease.call(this, props);
            postEase(this, plan);
            return r;
        };
        Clutter.Actor.prototype.ease_property = function (propName, value, params) {
            if (skipActor(this))
                return orig.easeProperty.call(this, propName, value, params);
            const plan = planEase(this, params, propName, value);
            const r = orig.easeProperty.call(this, propName, value, params);
            postEase(this, plan);
            return r;
        };
        if (orig.easeAsync) {
            Clutter.Actor.prototype.easeAsync = function (props) {
                if (skipActor(this))
                    return orig.easeAsync.call(this, props);
                const plan = planEase(this, props, null, null);
                const r = orig.easeAsync.call(this, props);
                postEase(this, plan);
                return r;
            };
        }
        St.Adjustment.prototype.ease = function (value, params) {
            const plan = planEase(this, params, 'value', value);
            const r = orig.adjustmentEase.call(this, value, params);
            postEase(this, plan);
            return r;
        };

        // Optional: ease the compiz-alike-magic-lamp-effect minimize/unminimize
        // timeline so it decelerates instead of stopping dead. Live-toggleable.
        this._installMagicLampHooks();
        this._settings.connectObject(
            'changed::magic-lamp-easing', () => this._installMagicLampHooks(),
            this);

        this._installOverviewPatch();
        this._settings.connectObject(
            'changed::overview-patch', () => {
                this._removeOverviewPatch();
                this._installOverviewPatch();
            },
            this);

        this._installWorkspacePatch();
        this._settings.connectObject(
            'changed::workspace-switch', () => {
                this._removeWorkspacePatch();
                this._installWorkspacePatch();
            },
            this);
    }

    // GNOME's Overview defers a hide() requested while an animation is still
    // running: the close only starts once the open finished, which users read
    // as "it replayed". The shell's own touchpad gestures never hit this
    // because they exit through the gesture channel, which retargets the
    // state adjustment from wherever it currently is (and lands right on this
    // extension's continuity engine). Route deferred hides through that same
    // exit. The open chain's completion callback would fire afterwards and
    // corrupt the state machine (HIDING -> SHOWN throws), so it is swallowed
    // once per takeover. Everything is feature-tested; any missing private
    // path degrades to stock behavior.
    _installOverviewPatch() {
        const ov = Main.overview;
        if (!this._settings.get_boolean('overview-patch') ||
            !ov?._animateNotVisible || !ov?._animateVisible ||
            !ov?._showDone ||
            !ov?._overview?.controls?.gestureEnd ||
            !ov?._changeShownState || !ov?._hideDone) {
            this._overviewPatched = false;
            return;
        }
        this._overviewPatched = true;
        this._origAnimateNotVisible = ov._animateNotVisible.bind(ov);
        this._origAnimateVisible = ov._animateVisible.bind(ov);
        this._origShowDone = ov._showDone.bind(ov);
        const origAnimateNotVisible = this._origAnimateNotVisible;
        const origAnimateVisible = this._origAnimateVisible;
        const origShowDone = this._origShowDone;
        const settings = this._settings;

        // Symmetric takeover: a show requested during an animation ALSO exits
        // through the gesture channel (reopening mid-close works, and the
        // deferred show of a triple-click reverses instead of queueing).
        // Deliberately NOT gated on the continuity setting: the hide takeover
        // is the fix for the reported complaint (so it honors the switch),
        // while the show direction has no native defect to opt out of.
        ov._animateVisible = function (state) {
            if (this._visible && this._animationInProgress &&
                this._shownState === 'HIDING') {
                try {
                    // Stock _animateVisible sets this flag; without it
                    // Main.overview.closing stays true for the takeover's
                    // duration and window animations misjudge the overview
                    // state around the reversal.
                    this._visibleTarget = true;
                    this._changeShownState('SHOWING');
                    this._overview.controls.gestureEnd(state, 250,
                        () => this._showDone());
                    this._watchTakeoverSettle();
                    return;
                } catch {
                    // fall through to stock deferral
                }
            }
            origAnimateVisible.call(this, state);
        };
        ov._animateNotVisible = function () {
            // NOTE: hide() clears _shown before calling here, so it must not
            // be part of the gate; SHOWING alone excludes the startup path.
            if (settings.get_boolean('continuity') &&
                this._visible && this._animationInProgress &&
                this._shownState === 'SHOWING') {
                try {
                    this._visibleTarget = false;
                    this._changeShownState('HIDING');
                    Main.panel.style = 'transition-duration: 250ms;';
                    this._overview.controls.gestureEnd(0, 250,
                        () => this._hideDone());
                    this._watchTakeoverSettle();
                    return;
                } catch {
                    // fall through to stock deferral
                }
            }
            origAnimateNotVisible.call(this);
        };
        ov._showDone = function () {
            // A takeover leaves the open chain's completion stale: it would
            // flip the shown state back to SHOWN from HIDING and throw. A
            // stale completion is recognized by state, not by counting: a
            // legitimate _showDone only ever completes while SHOWING. (The
            // interrupted open's callback usually never fires at all, so a
            // counter would leak and swallow the NEXT legitimate one, which
            // wedged the overview behind an _animationInProgress that never
            // cleared.)
            if (this._shownState !== 'SHOWING')
                return;
            origShowDone.call(this);
        };
        ov._watchTakeoverSettle = () => {
            // gestureEnd's completion is completion-only: if THIS transition
            // is interrupted (another takeover), its done-callback never runs
            // and _animationInProgress would stay true forever, wedging the
            // overview. The 'stopped' signal fires on interruption too, so it
            // settles the state machine whenever the takeover's transition
            // ends without completing; a newer takeover has already moved the
            // shown state, which makes the guard a no-op for stale watchers.
            // The connection is transition-scoped: it dies with the
            // stateAdjustment's 'value' transition, nothing to disconnect.
            const tr = ov._overview.controls._stateAdjustment
                ?.get_transition?.('value');
            tr?.connect('stopped', (t, finished) => {
                if (finished)
                    return;  // gestureEnd's own onComplete handles it
                if (ov._shownState === 'HIDING' && !ov._visibleTarget)
                    ov._hideDone();
                else if (ov._shownState === 'SHOWING' && ov._visibleTarget)
                    ov._showDone();
            });
        };
    }

    _removeOverviewPatch() {
        if (!this._overviewPatched)
            return;
        const ov = Main.overview;
        if (ov?._animateNotVisible)
            ov._animateNotVisible = this._origAnimateNotVisible;
        if (ov?._animateVisible)
            ov._animateVisible = this._origAnimateVisible;
        if (ov?._showDone)
            ov._showDone = this._origShowDone;
        delete ov._watchTakeoverSettle;
        this._overviewPatched = false;
    }

    // Workspace switching continuity. Stock GNOME tears the whole switch
    // down when a second switch arrives mid-flight: mutter emits
    // kill-switch-workspace, the controller destroys the animation groups,
    // and the new switch replays from its own base workspace, so the slide
    // teleports home and restarts. With the workspace-switch setting on,
    // two things change. Fresh groups are built over EVERY workspace (the
    // layout the touchpad-gesture path already uses), so any later target
    // exists inside them. And a kill is deferred for one main-loop turn:
    // the new switch arrives in that same batch, the existing groups are
    // simply retargeted, and the slide keeps its position and velocity
    // through the interruption. Nothing following the kill (animation
    // killed for real) still cancels via the idle fallback.
    _installWorkspacePatch() {
        const Controller = WorkspaceAnimation.WorkspaceAnimationController;
        if (!this._settings.get_boolean('workspace-switch') ||
            !Controller?.prototype?.animateSwitch ||
            !Controller?.prototype?.cancelSwitchAnimation ||
            !Controller?.prototype?._prepareWorkspaceSwitch ||
            !Controller?.prototype?._finishWorkspaceSwitch) {
            this._workspacePatched = false;
            return;
        }
        this._workspacePatched = true;
        const proto = Controller.prototype;
        this._origAnimateSwitch = proto.animateSwitch;
        this._origCancelSwitch = proto.cancelSwitchAnimation;
        const origAnimateSwitch = this._origAnimateSwitch;
        const origCancelSwitch = this._origCancelSwitch;

        proto.cancelSwitchAnimation = function () {
            if (!this._switchData || this._switchData.gestureActivated) {
                origCancelSwitch.call(this);
                return;
            }
            // Defer the teardown: a switch-workspace follows this kill in
            // the same mutter batch, and the patched animateSwitch below
            // retargets instead of rebuilding.
            if (!this._wsDeferKillId) {
                this._wsDeferKillId = GLib.idle_add(GLib.PRIORITY_DEFAULT,
                    () => {
                        this._wsDeferKillId = 0;
                        if (this._switchData &&
                                !this._switchData.gestureActivated)
                            origCancelSwitch.call(this);
                        return GLib.SOURCE_REMOVE;
                    });
            }
        };

        proto.animateSwitch = function (from, to, direction, onComplete) {
            if (this._wsDeferKillId && this._switchData &&
                    !this._switchData.gestureActivated) {
                // The interrupted switch: retarget the live groups to the
                // new workspace. Skipping the rebuild is the whole point;
                // the ease wrapper's continuity engine bridges the
                // retarget with the measured velocity.
                GLib.source_remove(this._wsDeferKillId);
                this._wsDeferKillId = 0;
                const toWs = global.workspace_manager
                    .get_workspace_by_index(to);
                // Groups that the STOCK animateSwitch armed (possible when
                // this switch was already in flight before the setting or
                // the extension turned on) only cover [from, to]; asking
                // those for an outside workspace throws inside stock
                // code. Tear them down and take the fresh path below.
                const covered = toWs !== null && this._switchData.monitors.every(
                    mg => mg._workspaceGroups.some(
                        g => g.workspace.index() === to));
                if (covered) {
                    this._swipeTracker.enabled = false;
                    for (const monitorGroup of this._switchData.monitors) {
                        const params = {
                            // WINDOW_ANIMATION_TIME is module-private on
                            // GNOME 49 and only exported from 50 on; a
                            // missing export would hand stock an undefined
                            // duration and make the retarget instant.
                            duration:
                                WorkspaceAnimation.WINDOW_ANIMATION_TIME ??
                                250,
                            mode: Clutter.AnimationMode.EASE_OUT_CUBIC,
                        };
                        if (monitorGroup.index ===
                                Main.layoutManager.primaryIndex) {
                            params.onComplete = () => {
                                this._finishWorkspaceSwitch(this._switchData);
                                if (onComplete)
                                    onComplete();
                                this._swipeTracker.enabled = true;
                            };
                        }
                        monitorGroup.ease_property('progress',
                            monitorGroup.getWorkspaceProgress(toWs), params);
                    }
                    return;
                }
                origCancelSwitch.call(this);
            }
            // Fresh switch: stock path, but the groups cover every
            // workspace so a later interrupt can retarget inside them.
            const origPrepare = this._prepareWorkspaceSwitch;
            this._prepareWorkspaceSwitch = () => origPrepare.call(this);
            try {
                origAnimateSwitch.call(this, from, to, direction,
                    onComplete);
            } finally {
                this._prepareWorkspaceSwitch = origPrepare;
            }
        };
    }

    _removeWorkspacePatch() {
        if (!this._workspacePatched)
            return;
        // Paired source_remove for a pending deferred kill (the project's
        // eGo rule since v0.1 finding 4): dropping it lets the in-flight
        // switch simply run to its own completion.
        const controller = Main.wm?._workspaceAnimation;
        if (controller?._wsDeferKillId) {
            GLib.source_remove(controller._wsDeferKillId);
            controller._wsDeferKillId = 0;
        }
        const proto = WorkspaceAnimation.WorkspaceAnimationController
            .prototype;
        proto.animateSwitch = this._origAnimateSwitch;
        proto.cancelSwitchAnimation = this._origCancelSwitch;
        this._workspacePatched = false;
    }

    _resolveCurve(settings) {
        try {
            const userCurves = Curves.parseUserCurves(settings.get_strv('user-curves'));
            const id = settings.get_string('selected-curve');
            const c = Curves.findCurve(id, userCurves) ??
                Curves.findCurve(Curves.defaultCurveId(), userCurves);
            if (c?.kind === 'spring')
                return {...c, solver: settings.get_string('spring-solver')};
            return c;
        } catch {
            // malformed user-curve data in GSettings: fall back to default
            return null;
        }
    }

    // One-time: carry the legacy `mode` key into the curve library.
    _migrateSettings() {
        // v9 removed two duplicate presets from the gallery (quint next
        // to quart, in-out-quint identical to in-out-expo). Anyone whose
        // selection still points at the removed ids would silently fall
        // back to Balanced on every lookup; remap once to the nearest
        // kept preset instead.
        const sel = this._settings.get_string('selected-curve');
        if (sel === 'preset:ease-out-quint') {
            this._settings.set_string('selected-curve',
                'preset:ease-out-quart');
        } else if (sel === 'preset:ease-in-out-quint') {
            this._settings.set_string('selected-curve',
                'preset:ease-in-out-expo');
        }
        // v10 removed the spring engine; anyone still selecting it lands
        // back on the bridge engine (the only one left). Reads of values
        // outside the schema choices still return the stored string.
        if (this._settings.get_string('engine') === 'spring')
            this._settings.set_string('engine', 'bridge');
        if (this._settings.get_int('schema-version') >= 2)
            return;
        const oldMode = this._settings.get_string('mode');
        const mapped = Curves.MIGRATION_MAP[oldMode];
        if (mapped)
            this._settings.set_string('selected-curve', mapped);
        this._settings.set_int('schema-version', 2);
    }

    _installMagicLampHooks() {
        global.window_manager.disconnectObject(this);
        if (!this._settings.get_boolean('magic-lamp-easing'))
            return;
        global.window_manager.connectObject(
            'minimize', (_wm, actor) => this._easeMagicLamp(actor),
            'unminimize', (_wm, actor) => this._easeMagicLamp(actor),
            this);
    }

    _easeMagicLamp(actor) {
        if (!actor) return;
        // Defer one main-loop iteration: signal handlers run synchronously in
        // connection order, so depending on load order our handler may fire
        // before magic-lamp has called add_effect_with_name(). By the next
        // HIGH_IDLE the effect (and the timeline created in its vfunc_set_actor)
        // is in place, and the timeline's first new-frame has not fired yet.
        // The deferral is PER ACTOR: several windows can be minimized in one
        // dispatch, and a single shared id would cancel every window's
        // deferral but the last (that one kept the native full-speed drop).
        // A plain Map (not a WeakMap) so disable() can enumerate and remove
        // every pending id; eGo review requires a matching source_remove
        // for each scheduled source (v0.1 rejection, finding 4).
        if (!this._lampDefers)
            this._lampDefers = new Map();
        const prevId = this._lampDefers.get(actor);
        if (prevId)
            GLib.source_remove(prevId);
        const id = GLib.idle_add(GLib.PRIORITY_HIGH_IDLE, () => {
            this._lampDefers.delete(actor);
            if (!this._magicLampTimers)
                this._magicLampTimers = new WeakMap();
            const prev = this._magicLampTimers.get(actor);
            const duration = this._settings.get_int('magic-lamp-duration-ms');
            for (const name of [MAGIC_LAMP_MINIMIZE, MAGIC_LAMP_UNMINIMIZE]) {
                const effect = actor.get_effect(name);
                const timeline = effect?.timerId;
                if (timeline?.set_progress_mode) {
                    timeline.set_progress_mode(Clutter.AnimationMode.EASE_OUT_CUBIC);
                    // Use one configurable duration for both directions so
                    // they feel symmetric; the default preserves the old timing.
                    timeline.set_duration(duration);
                    // Interruption: if the previous magic-lamp timeline for
                    // this window was still mid-flight, fast-forward the new
                    // one so the effect continues instead of teleporting back
                    // to the start of its deformation.
                    const previousDuration = prev?.timeline?.get_duration?.() ?? duration;
                    const elapsed = prev?.timeline?.is_playing?.()
                        ? prev.timeline.get_elapsed_time() : 0;
                    if (previousDuration > 0 && elapsed > 0 && elapsed < previousDuration)
                        // Keep the same progress if the duration changed since
                        // the interrupted animation started.
                        timeline.advance(Math.floor(elapsed * duration / previousDuration));
                    this._magicLampTimers.set(actor, {timeline});
                }
            }
            return GLib.SOURCE_REMOVE;
        });
        this._lampDefers.set(actor, id);
    }

    disable() {
        Clutter.Actor.prototype.ease = this._orig.ease;
        Clutter.Actor.prototype.ease_property = this._orig.easeProperty;
        if (this._orig.easeAsync)
            Clutter.Actor.prototype.easeAsync = this._orig.easeAsync;
        St.Adjustment.prototype.ease = this._orig.adjustmentEase;
        global.stage.disconnectObject(this);
        global.window_manager.disconnectObject(this);
        this._settings.disconnectObject(this);
        // Paired source_remove for every pending magic-lamp deferral (eGo
        // rule since v0.1's finding 4; the Map lets us enumerate them all).
        if (this._lampDefers) {
            for (const id of this._lampDefers.values())
                GLib.source_remove(id);
            this._lampDefers.clear();
        }
        this._removeOverviewPatch();
        this._removeWorkspacePatch();
        bridgeShutdown();
        this._orig = null;
        this._settings = null;
    }
}
